"""Compatibility re-export for the canonical cluster role engine."""

from .cluster.models import (
    CapabilityGrant,
    ClusterRole,
    CoordinatorEpoch,
    CoordinatorLease,
    PromotionDecision,
    RoleAssignment,
    RoleChange,
)
from .cluster.roles import (
    HEARTBEAT_TIMEOUT_SECONDS,
    FencingError,
    RoleAuthorizationError,
    RoleState,
    can_promote,
    hash_invite,
    new_fencing_token,
    promote_subcoordinator,
    rejoin_as_worker,
    renew_lease,
)
from .cluster.state import role_state_from_dict, role_state_to_dict

__all__ = [
    "HEARTBEAT_TIMEOUT_SECONDS",
    "CapabilityGrant",
    "ClusterRole",
    "CoordinatorEpoch",
    "CoordinatorLease",
    "FencingError",
    "PromotionDecision",
    "RoleAssignment",
    "RoleAuthorizationError",
    "RoleChange",
    "RoleState",
    "can_promote",
    "hash_invite",
    "new_fencing_token",
    "promote_subcoordinator",
    "rejoin_as_worker",
    "renew_lease",
    "role_state_from_dict",
    "role_state_to_dict",
]
