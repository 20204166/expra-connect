"""Server-side authenticated request validation and remote-operation dispatch.

The inbound service owns authorization and dispatch; wire, socket, server, and
client-provider mechanics remain in their focused modules.
"""

import hmac
import json
import logging
import math
import threading
import time
from collections.abc import Callable
from typing import Any

from ..cluster.roles import RoleAuthorizationError
from ..data.permissions import (
    READ_CAPABILITIES,
    NodeCapability,
    NodePermission,
)
from ..identity import NodeId, node_identity_fingerprint
from ..observability import ObservabilityWatcher, observation_scope
from ..surfaces.protocol import SURFACE_ACCESS_BY_OPERATION, SURFACE_OPERATIONS
from ..surfaces.provider import dispatch_surface_request
from ..transport.server import (
    PEER_SERVICE_DEFAULT_PORT,
    RemoteSocketServer,
)
from ..transport.socket_transport import (
    MemoryRemoteTransport,
    SocketRemoteTransport,
    TLSRemoteTransport,
    build_trusted_transport,
)
from .models import (
    NodeSnapshot,
    NodeStatus,
    ProcessActionKind,
    ProcessActionResult,
    ProcessRef,
    ProcessTerminationRequest,
    file_candidate_to_dict,
    node_snapshot_to_dict,
    process_action_result_to_dict,
    process_candidate_to_dict,
    resource_summary_to_dict,
)
from .process_backend import RemoteProcessActionBackend
from .session import LogicalSessionRegistry
from .wire_protocol import (
    DEFAULT_FRESHNESS_SECONDS,
    DEFAULT_IDEMPOTENCY_MAX_ENTRIES,
    DEFAULT_IDEMPOTENCY_TTL_SECONDS,
    DEFAULT_MAX_ACTIVE_HANDLERS,
    DEFAULT_REPLAY_MAX_ENTRIES,
    DEFAULT_REPLAY_TTL_SECONDS,
    MAX_ENVELOPE_BYTES,
    OP_REQUIRED_CAPABILITY,
    OP_REQUIRED_PERMISSION,
    OPERATION_SAFETY,
    PAIRING_MODE_TRANSACTIONAL,
    REMOTE_PROTOCOL_VERSION,
    ROLE_OPERATIONS,
    CapabilityElevationRequest,
    IdempotencyCache,
    PairingRequest,
    PeerGrant,
    RemoteAuthError,
    RemoteAuthorizationError,
    RemoteExecutionError,
    RemoteProtocolError,
    RemoteRequest,
    RemoteResponse,
    RemoteTransportError,
    RemoteUnavailableError,
    ReplayCache,
    parse_hello_capabilities,
    sign_request,
    sign_response,
    validate_hello_payload,
    validate_operation_params,
    verify_request,
    verify_response,
)

LOGGER = logging.getLogger(__name__)


__all__ = [
    "DEFAULT_FRESHNESS_SECONDS",
    "DEFAULT_IDEMPOTENCY_MAX_ENTRIES",
    "DEFAULT_IDEMPOTENCY_TTL_SECONDS",
    "DEFAULT_MAX_ACTIVE_HANDLERS",
    "DEFAULT_REPLAY_MAX_ENTRIES",
    "DEFAULT_REPLAY_TTL_SECONDS",
    "MAX_ENVELOPE_BYTES",
    "OPERATION_SAFETY",
    "OP_REQUIRED_CAPABILITY",
    "OP_REQUIRED_PERMISSION",
    "PAIRING_MODE_TRANSACTIONAL",
    "PEER_SERVICE_DEFAULT_PORT",
    "READ_CAPABILITIES",
    "REMOTE_PROTOCOL_VERSION",
    "ROLE_OPERATIONS",
    "CapabilityElevationRequest",
    "MemoryRemoteTransport",
    "PairingRequest",
    "PeerGrant",
    "RemoteAuthError",
    "RemoteAuthorizationError",
    "RemoteExecutionError",
    "RemoteProcessActionBackend",
    "RemoteProtocolError",
    "RemoteRequest",
    "RemoteResponse",
    "RemoteService",
    "RemoteSocketServer",
    "RemoteTransportError",
    "RemoteUnavailableError",
    "ReplayCache",
    "SocketRemoteTransport",
    "TLSRemoteTransport",
    "build_trusted_transport",
    "parse_hello_capabilities",
    "sign_request",
    "sign_response",
    "validate_hello_payload",
    "validate_operation_params",
    "verify_request",
    "verify_response",
]


class RemoteService:
    """Server-side authenticated request boundary."""

    def __init__(
        self,
        *,
        node_id: NodeId,
        display_name: str,
        hostname: str,
        platform: str | None,
        status: NodeStatus,
        capabilities: frozenset[NodeCapability],
        provider: Any,
        secret: str,
        app_version: str = "",
        clock: Callable[[], float] = time.time,
        session_clock: Callable[[], float] = time.monotonic,
        freshness_seconds: float = DEFAULT_FRESHNESS_SECONDS,
        replay_cache: ReplayCache | None = None,
        permissions: frozenset[NodePermission] | None = None,
        process_manager: Any | None = None,
        expected_caller_id: NodeId | None = None,
        grants: dict[NodeId, PeerGrant] | None = None,
        cluster_capability_grants: tuple[Any, ...] = (),
        identity_fingerprint: str | None = None,
        transport_fingerprint: str | None = None,
        root_public_key: str | None = None,
        transport_generation: int | None = None,
        transport_proof: str | None = None,
        cluster_id: str | None = None,
        coordinator_epoch: int | None = None,
        fencing_token: str | None = None,
        role_handler: Callable[[RemoteRequest], dict[str, Any]] | None = None,
        trust_revoke_handler: Callable[[NodeId], dict[str, Any]] | None = None,
        trust_revoke_commit: Callable[[], None] | None = None,
        require_dashboard_share: bool = False,
        capability_share: Any | None = None,
        surface_registry: Any | None = None,
        idempotency_cache: IdempotencyCache | None = None,
        idempotency_ttl_seconds: float = DEFAULT_IDEMPOTENCY_TTL_SECONDS,
        idempotency_max_entries: int = DEFAULT_IDEMPOTENCY_MAX_ENTRIES,
        idempotency_store: Any | None = None,
        observer: ObservabilityWatcher | None = None,
    ) -> None:
        self._node_id = node_id
        self._display_name = display_name
        self._hostname = hostname
        self._platform = platform
        self._status = status
        self._capabilities = capabilities
        self._provider = provider
        self._observer = observer
        self._process_manager = process_manager
        self._expected_caller_id = expected_caller_id
        self._identity_fingerprint = identity_fingerprint or node_identity_fingerprint(
            node_id
        )
        self._transport_fingerprint = transport_fingerprint
        self._root_public_key = root_public_key
        self._transport_generation = transport_generation
        self._transport_proof = transport_proof
        self._validate_secret(secret)
        self._secret = secret
        self._grant_mode = grants is not None
        self._grant_lock = threading.RLock()
        self._fence_lock = threading.Lock()
        self._grants = dict(grants or {})
        self._cluster_capability_grants = tuple(cluster_capability_grants)
        for grant in self._grants.values():
            self._validate_secret(grant.secret)
            if grant.expires_at is not None and not math.isfinite(
                float(grant.expires_at)
            ):
                raise ValueError("peer grant expiry must be finite")
        self._app_version = app_version
        self._clock = clock
        self._freshness_seconds = freshness_seconds
        self._replay_cache = (
            replay_cache if replay_cache is not None else ReplayCache(clock=clock)
        )
        self._permissions = (
            frozenset(permissions)
            if permissions is not None
            else frozenset(
                permission
                for permission in NodePermission
                if permission.value in {capability.value for capability in capabilities}
                and permission
                not in {
                    NodePermission.PROCESS_TERMINATION,
                    NodePermission.PROCESS_FORCE_TERMINATION,
                    NodePermission.CLEANUP,
                }
            )
        )
        self._cluster_id = cluster_id
        self._coordinator_epoch = coordinator_epoch
        self._fencing_token = fencing_token
        self._role_handler = role_handler
        self._trust_revoke_handler = trust_revoke_handler
        self._trust_revoke_commit = trust_revoke_commit
        self._require_dashboard_share = require_dashboard_share
        self._dashboard_shares: dict[NodeId, float] = {}
        self._capability_share = capability_share
        self._surface_registry = surface_registry
        if idempotency_cache is None:
            idempotency_cache = IdempotencyCache(clock=clock, ttl_seconds=idempotency_ttl_seconds, max_entries=idempotency_max_entries, state_store=idempotency_store)  # fmt: skip
        self._idempotency = idempotency_cache
        self._sessions = LogicalSessionRegistry(
            clock=session_clock, ttl_seconds=freshness_seconds * 10
        )
        self._grant_version = 0

    @staticmethod
    def _validate_secret(secret: str) -> None:
        if not isinstance(secret, str) or len(secret) != 64:
            raise ValueError("peer credentials must be 256-bit hex text")
        try:
            decoded = bytes.fromhex(secret)
        except ValueError as error:
            raise ValueError("peer credentials must be hexadecimal") from error
        if len(decoded) != 32:  # bytes.fromhex accepts whitespace
            raise ValueError("peer credentials must be 256-bit hex text")

    def _assert_grant_snapshot_current(
        self, grant: PeerGrant | None, grant_version: int
    ) -> None:
        with self._grant_lock:
            if grant_version != self._grant_version:
                raise RemoteAuthorizationError("caller permission changed")
            if grant is not None and (
                grant.expires_at is not None and self._clock() >= grant.expires_at
            ):
                raise RemoteAuthorizationError("caller grant has expired")

    def _authorize_request(
        self, request: RemoteRequest, grant: PeerGrant | None
    ) -> Any | None:
        required = OP_REQUIRED_CAPABILITY.get(request.op)
        if required is None:
            raise RemoteProtocolError(f"unknown operation: {request.op}")
        if required not in self._capabilities:
            raise RemoteAuthorizationError(f"node is not authorised for {request.op}")
        permission = OP_REQUIRED_PERMISSION[request.op]
        permissions = grant.permissions if grant is not None else self._permissions
        cluster_grant = None
        if request.caller_node_id is not None:
            cluster_grant = next(
                (
                    item
                    for item in self._cluster_capability_grants
                    if item.subject == request.caller_node_id
                    and item.target == self._node_id
                    and self._clock() < item.expires_at
                ),
                None,
            )
            if cluster_grant is not None:
                permissions = permissions & cluster_grant.permissions
                if not permissions:
                    raise RemoteAuthorizationError(
                        "cluster capability grant has no Pair permission overlap"
                    )
        if permission not in permissions:
            raise RemoteAuthorizationError(f"caller lacks permission for {request.op}")
        if request.op in SURFACE_OPERATIONS:
            validate_operation_params(request.op, request.params)
            if request.caller_node_id is None:
                raise RemoteAuthorizationError(
                    "caller identity required for surface requests"
                )
            if self._surface_registry is None:
                raise RemoteUnavailableError("surface sharing is unavailable")
            try:
                self._surface_registry.authorize(
                    request.caller_node_id,
                    request.params["surface_id"],
                    access=SURFACE_ACCESS_BY_OPERATION[request.op],
                    action=request.params.get("action"),
                    cluster_sources=(
                        (request.caller_node_id,) if cluster_grant is not None else ()
                    ),
                )
            except PermissionError as error:
                raise RemoteAuthorizationError(str(error)) from error
        return cluster_grant

    def handle(
        self, envelope_text: str, *, connection_generation: str | None = None
    ) -> str:
        try:
            envelope = json.loads(envelope_text)
        except (ValueError, TypeError) as error:
            raise RemoteProtocolError("envelope is not valid JSON") from error
        caller_node_id = self._caller_from_json(envelope)
        credential = self._secret
        grant: PeerGrant | None = None
        with self._grant_lock:
            grant_version = self._grant_version
            if self._grant_mode:
                if caller_node_id is None:
                    raise RemoteAuthError("request caller identity is required")
                grant = self._grants.get(caller_node_id)
                if grant is None:
                    raise RemoteAuthError("request caller identity is unknown")
                if grant.expires_at is not None and self._clock() >= grant.expires_at:
                    raise RemoteAuthError("request caller grant has expired")
                credential = grant.secret
        try:
            request = verify_request(
                envelope,
                secret=credential,
                clock=self._clock,
                freshness_seconds=self._freshness_seconds,
                replay_cache=self._replay_cache,
            )
        except RemoteAuthError as error:
            op = envelope.get("op") if isinstance(envelope, dict) else None
            operation_safety = OPERATION_SAFETY.get(op) if isinstance(op, str) else None
            if "replayed" not in str(error) or operation_safety not in {
                "read",
                "retry_safe",
                "unsafe",
            }:
                raise
            request = verify_request(
                envelope,
                secret=credential,
                clock=self._clock,
                freshness_seconds=self._freshness_seconds,
                replay_cache=ReplayCache(clock=self._clock),
            )
        response_secret = grant.secret if grant is not None else self._secret
        if (
            self._expected_caller_id is not None
            and request.caller_node_id != self._expected_caller_id
        ):
            raise RemoteAuthError("request caller identity is invalid")
        if request.node_id != self._node_id:
            raise RemoteAuthError("request target identity is invalid")
        session_id = self._sessions.authenticate(
            request, connection_generation=connection_generation
        )
        if request.op in ROLE_OPERATIONS:
            self._verify_role_fence(request)
        cache_key = (
            request.caller_node_id.value
            if request.caller_node_id is not None
            else request.node_id.value,
            request.request_id,
        )
        fingerprint = json.dumps(
            {"op": request.op, "params": request.params},
            sort_keys=True,
            separators=(",", ":"),
        )

        def solve() -> dict[str, Any]:
            with observation_scope(self._observer, f"service:{request.op}"):
                self._assert_grant_snapshot_current(grant, grant_version)
                result = self._solve(request, grant=grant)
                self._sessions.assert_current(session_id, connection_generation)
                self._assert_grant_snapshot_current(grant, grant_version)
            return result

        try:
            self._assert_grant_snapshot_current(grant, grant_version)
            self._authorize_request(request, grant)
            payload: dict[str, Any] | None = (
                self._idempotency.run(cache_key, fingerprint, solve)
                if OPERATION_SAFETY.get(request.op) != "read"
                else solve()
            )
            if request.op in ROLE_OPERATIONS:
                self._verify_role_fence(request)
            self._sessions.assert_current(session_id, connection_generation)
            self._assert_grant_snapshot_current(grant, grant_version)
            self._authorize_request(request, grant)
        except (
            RemoteAuthorizationError,
            PermissionError,
            RoleAuthorizationError,
        ) as error:
            response = sign_response(
                node_id=self._node_id.value,
                request_id=request.request_id,
                status="error",
                error=(
                    "capability_unavailable"
                    if "not authorised" in str(error)
                    else "permission_denied"
                ),
                timestamp=self._clock(),
                secret=response_secret,
                session_id=session_id,
                connection_generation=connection_generation,
            )
            return json.dumps(response)
        except RemoteUnavailableError:
            response = sign_response(
                node_id=self._node_id.value,
                request_id=request.request_id,
                status="error",
                error="target_offline",
                timestamp=self._clock(),
                secret=response_secret,
                session_id=session_id,
                connection_generation=connection_generation,
            )
            return json.dumps(response)
        except RemoteProtocolError:
            raise
        except Exception:  # noqa: BLE001 - failures become stable signed errors.
            LOGGER.warning(
                "Remote operation %s failed on %s",
                request.op,
                self._node_id,
            )
            response = sign_response(
                node_id=self._node_id.value,
                request_id=request.request_id,
                status="error",
                error="execution_failed",
                timestamp=self._clock(),
                secret=response_secret,
                session_id=session_id,
                connection_generation=connection_generation,
            )
            return json.dumps(response)
        if request.op == "revoke_self" and self._trust_revoke_commit is not None:
            self._trust_revoke_commit()
        response_status = "ok"
        response_error = None
        try:
            json.dumps(payload, allow_nan=False)
        except (TypeError, ValueError):
            LOGGER.warning("Remote operation %s returned an invalid result", request.op)
            response_status, response_error, payload = "error", "execution_failed", None
        response = sign_response(
            node_id=self._node_id.value,
            request_id=request.request_id,
            status=response_status,
            payload=payload,
            error=response_error,
            timestamp=self._clock(),
            secret=response_secret,
            session_id=session_id,
            connection_generation=connection_generation,
        )
        return json.dumps(response, allow_nan=False)

    def update_grants(self, grants: dict[NodeId, PeerGrant]) -> None:
        """Replace the live target ACL after an atomic settings update."""
        validated = dict(grants)
        for grant in validated.values():
            self._validate_secret(grant.secret)
            if grant.expires_at is not None and not math.isfinite(
                float(grant.expires_at)
            ):
                raise ValueError("peer grant expiry must be finite")
        with self._grant_lock:
            self._grant_mode = True
            self._grants = validated
            self._grant_version += 1

    def update_cluster_capability_grants(self, grants: tuple[Any, ...]) -> None:
        """Replace the separate cluster ACL without changing Pair grants."""
        with self._grant_lock:
            self._cluster_capability_grants = tuple(grants)
            self._grant_version += 1

    @staticmethod
    def _caller_from_json(envelope: Any) -> NodeId | None:
        if not isinstance(envelope, dict):
            return None
        caller = envelope.get("caller_node_id")
        try:
            return NodeId(caller) if isinstance(caller, str) and caller else None
        except ValueError:
            return None

    def _solve(
        self, request: RemoteRequest, *, grant: PeerGrant | None = None
    ) -> dict[str, Any]:
        cluster_grant = self._authorize_request(request, grant)
        validate_operation_params(request.op, request.params)
        if request.op in ROLE_OPERATIONS:
            if self._role_handler is None:
                raise RemoteUnavailableError("role operations are unavailable")
            return self._role_handler(request)
        if request.op == "revoke_self":
            if request.caller_node_id is None:
                raise RemoteAuthorizationError(
                    "caller identity required for self-revocation"
                )
            if self._trust_revoke_handler is None:
                raise RemoteUnavailableError("trust revocation is unavailable")
            return self._trust_revoke_handler(request.caller_node_id)
        if request.op == "capability_request":
            if request.caller_node_id is None:
                raise RemoteAuthorizationError(
                    "caller identity required for capability requests"
                )
            if self._capability_share is None:
                raise RemoteUnavailableError("capability sharing is unavailable")
            try:
                result = self._capability_share.request(
                    request.caller_node_id,
                    request.params["capability"],
                    request.params["params"],
                )
            except PermissionError as error:
                raise RemoteAuthorizationError(str(error)) from error
            return {"result": result}
        if request.op in SURFACE_OPERATIONS:
            result = dispatch_surface_request(
                self._surface_registry,
                request,
                cluster_grant,
            )
            return {"result": result}
        if request.op == "hello":
            return {
                "ok": True,
                "node_id": self._node_id.value,
                "identity_fingerprint": self._identity_fingerprint,
                "transport_fingerprint": self._transport_fingerprint,
                "root_public_key": self._root_public_key,
                "transport_generation": self._transport_generation,
                "transport_proof": self._transport_proof,
                "protocol_version": REMOTE_PROTOCOL_VERSION,
                "app_version": self._app_version,
                "capabilities": sorted(
                    capability.value for capability in self._capabilities
                ),
            }
        if request.op == "dashboard_snapshot":
            if (
                self._require_dashboard_share
                and request.caller_node_id not in self._dashboard_shares
            ):
                raise RemoteAuthorizationError("dashboard share is not active")
            if request.caller_node_id is not None:
                expiry = self._dashboard_shares.get(request.caller_node_id)
                if expiry is not None and self._clock() >= expiry:
                    self._dashboard_shares.pop(request.caller_node_id, None)
                    raise RemoteAuthorizationError("dashboard share has expired")
            snapshot = self._dashboard_snapshot()
            return {"snapshot": node_snapshot_to_dict(snapshot)}
        if request.op == "component_summary":
            resource = self._provider.component_summary(request.params["key"])
            return {
                "node_id": self._node_id.value,
                "resource": resource_summary_to_dict(resource),
            }
        if request.op == "process_candidates":
            processes = self._provider.process_candidates()
            return {"processes": [process_candidate_to_dict(p) for p in processes]}
        if request.op in {"process_request_quit", "process_force_quit"}:
            if self._status is not NodeStatus.ONLINE:
                raise RemoteUnavailableError("target is offline")
            if self._process_manager is None:
                raise RemoteExecutionError("process actions are unavailable")
            refs = request.params["processes"]
            action_kind = ProcessActionKind(request.params["action"])
            termination = ProcessTerminationRequest(
                target_node_id=self._node_id,
                processes=tuple(
                    ProcessRef(
                        node_id=self._node_id,
                        pid=int(item["pid"]),
                        create_time=float(item["create_time"]),
                    )
                    for item in refs
                ),
                action=action_kind,
            )
            if hasattr(self._process_manager, "terminate"):
                result = self._process_manager.terminate(termination)
            else:
                pids = [process.pid for process in termination.processes]
                create_times = {
                    process.pid: process.create_time
                    for process in termination.processes
                    if process.create_time is not None
                }
                action = (
                    self._process_manager.force_quit
                    if action_kind is ProcessActionKind.FORCE_QUIT
                    else self._process_manager.request_quit
                )
                result = action(pids, create_times)
            if not isinstance(result, ProcessActionResult):
                raise RemoteExecutionError("target returned an invalid action result")
            return process_action_result_to_dict(result)
        if request.op == "storage_candidates":
            candidates = self._provider.storage_candidates()
            return {"files": [file_candidate_to_dict(c) for c in candidates]}
        raise RemoteProtocolError(f"unknown operation: {request.op}")

    def _verify_role_fence(self, request: RemoteRequest) -> None:
        params = request.params
        with self._fence_lock:
            cluster_id = self._cluster_id
            coordinator_epoch = self._coordinator_epoch
            fencing_token = self._fencing_token
        if cluster_id is not None and params.get("cluster_id") != cluster_id:
            raise RemoteAuthorizationError("cluster identity is invalid")
        if coordinator_epoch is not None and params.get("epoch") != coordinator_epoch:
            raise RemoteAuthorizationError("coordinator epoch is stale")
        if fencing_token is not None and not hmac.compare_digest(
            str(params.get("fencing_token")), fencing_token
        ):
            raise RemoteAuthorizationError("coordinator fencing token is stale")

    def update_cluster_fence(
        self, *, cluster_id: str, coordinator_epoch: int, fencing_token: str
    ) -> None:
        with self._fence_lock:
            if self._cluster_id == cluster_id and self._coordinator_epoch is not None:
                if coordinator_epoch < self._coordinator_epoch:
                    raise RemoteAuthorizationError(
                        "cannot install an older coordinator epoch"
                    )
                if coordinator_epoch == self._coordinator_epoch:
                    if self._fencing_token is None or not hmac.compare_digest(
                        fencing_token, self._fencing_token
                    ):
                        raise RemoteAuthorizationError(
                            "coordinator fencing token conflicts"
                        )
                    return
            self._cluster_id = cluster_id
            self._coordinator_epoch = coordinator_epoch
            self._fencing_token = fencing_token

    def clear_dashboard_share(self, caller_node_id: NodeId) -> None:
        self._dashboard_shares.pop(caller_node_id, None)

    def start_dashboard_share_for(
        self, caller_node_id: NodeId, *, expires_at: float
    ) -> None:
        if expires_at <= self._clock():
            raise RemoteAuthorizationError("dashboard share expiry is invalid")
        self._dashboard_shares[caller_node_id] = expires_at

    def stop_dashboard_shares(self) -> None:
        self._dashboard_shares.clear()

    def _dashboard_snapshot(self) -> NodeSnapshot:
        dashboard = self._provider.dashboard_snapshot()
        return NodeSnapshot(
            node_id=self._node_id,
            display_name=self._display_name,
            hostname=self._hostname,
            platform=self._platform,
            status=self._status,
            capabilities=self._capabilities,
            scanned_at=dashboard.scanned_at,
            dashboard=dashboard,
        )
